<?php
/**
 * Core Apps catalog endpoint.
 *
 * Fetches the first-party ware catalog from the bazaar GitHub repo and returns
 * it to the manage page so users can discover and install core apps in one click.
 *
 * The catalog JSON lives at:
 *   https://raw.githubusercontent.com/RegionallyFamous/bazaar/main/wares/registry.json
 *
 * It follows the same shape as the remote registry index, so each ware entry has:
 *   slug, name, description, version, author, icon_url, download_url, tags
 *
 * Results are cached for 1 hour in a transient to avoid hammering GitHub.
 *
 * Route
 * ─────
 *   GET /bazaar/v1/core-apps
 *
 * @package Bazaar
 */

declare( strict_types=1 );

namespace Bazaar\REST;

defined( 'ABSPATH' ) || exit;

use Bazaar\WareLoaderInterface;
use Bazaar\WareLoader;
use Bazaar\WareRegistryInterface;
use Bazaar\WareRegistry;
use Bazaar\REST\JobsController;
use WP_REST_Server;
use WP_REST_Request;
use WP_REST_Response;
use WP_Error;

/**
 * Serves the first-party core apps catalog and provides a URL-based install route.
 */
final class CoreAppsController extends BazaarController {

	/**
	 * Route base.
	 *
	 * @var string
	 */
	protected $rest_base = 'core-apps';

	/**
	 * WareRegistry instance.
	 *
	 * @var WareRegistryInterface
	 */
	private WareRegistryInterface $registry;

	/**
	 * WareLoader instance.
	 *
	 * @var WareLoaderInterface
	 */
	private WareLoaderInterface $loader;

	/**
	 * Constructor.
	 *
	 * @param WareRegistryInterface    $registry Registry instance.
	 * @param WareLoaderInterface|null $loader   Loader; defaults to a new WareLoader.
	 */
	public function __construct( WareRegistryInterface $registry, ?WareLoaderInterface $loader = null ) {
		$this->registry = $registry;
		$this->loader   = $loader ?? new WareLoader( $registry );
	}

	/**
	 * URL of the raw registry JSON in the bazaar GitHub repo.
	 *
	 * Can be overridden via the `bazaar_core_apps_url` filter for self-hosted forks.
	 */
	private const REGISTRY_URL = 'https://raw.githubusercontent.com/RegionallyFamous/bazaar/main/wares/registry.json';

	/**
	 * Transient key.
	 */
	private const TRANSIENT = 'bazaar_core_apps';

	/**
	 * Cache TTL in seconds (1 hour).
	 */
	private const CACHE_TTL = HOUR_IN_SECONDS;

	/**
	 * HTTP request timeout.
	 */
	private const TIMEOUT = 8;

	/**
	 * Register routes.
	 */
	public function register_routes(): void {
		register_rest_route(
			$this->namespace,
			"/{$this->rest_base}",
			array(
				'methods'             => WP_REST_Server::READABLE,
				'callback'            => array( $this, 'get_catalog' ),
				'permission_callback' => $this->require_admin(),
			)
		);

		register_rest_route(
			$this->namespace,
			"/{$this->rest_base}/install",
			array(
				'methods'             => WP_REST_Server::CREATABLE,
				'callback'            => array( $this, 'install_from_url' ),
				'permission_callback' => $this->require_admin(),
				'args'                => array(
					'url' => array(
						'required'          => true,
						'type'              => 'string',
						'format'            => 'uri',
						'sanitize_callback' => 'esc_url_raw',
					),
				),
			)
		);
	}

	/**
	 * Path to the bundled fallback registry within the plugin.
	 */
	private const BUNDLED_REGISTRY = BAZAAR_DIR . 'wares/registry.json';

	/**
	 * Return the core apps catalog, fetching and caching from GitHub as needed.
	 * Falls back to the bundled wares/registry.json when the remote is unreachable.
	 *
	 * @return WP_REST_Response|WP_Error
	 */
	public function get_catalog(): WP_REST_Response|WP_Error {
		$cached = get_transient( self::TRANSIENT );
		if ( is_array( $cached ) && count( $cached ) > 0 ) {
			return new WP_REST_Response( $cached, 200 );
		}

		$url      = (string) apply_filters( 'bazaar_core_apps_url', self::REGISTRY_URL );
		$response = wp_remote_get(
			$url,
			array(
				'timeout'   => self::TIMEOUT,
				'sslverify' => true,
			)
		);

		if ( ! is_wp_error( $response ) ) {
			$code = (int) wp_remote_retrieve_response_code( $response );
			$body = wp_remote_retrieve_body( $response );
			$data = json_decode( $body, true );

			if ( 200 === $code && is_array( $data ) && isset( $data['wares'] ) && is_array( $data['wares'] ) ) {
				$wares = $this->sanitize_wares( $data['wares'] );
				set_transient( self::TRANSIENT, $wares, self::CACHE_TTL );
				return new WP_REST_Response( $wares, 200 );
			}
		}

		// Remote fetch failed or returned bad data — fall back to the bundled registry.
		$wares = $this->load_bundled_registry();
		if ( null !== $wares ) {
			// Cache briefly so the next request retries the remote sooner.
			set_transient( self::TRANSIENT, $wares, 5 * MINUTE_IN_SECONDS );
			return new WP_REST_Response( $wares, 200 );
		}

		return new WP_Error(
			'catalog_unavailable',
			__( 'Core apps catalog is unavailable.', 'bazaar' ),
			array( 'status' => 502 )
		);
	}

	/**
	 * Parse the bundled wares/registry.json and return sanitized entries.
	 * Returns null if the file is missing or unparseable.
	 *
	 * @return array<int, array<string, mixed>>|null
	 */
	private function load_bundled_registry(): ?array {
		if ( ! file_exists( self::BUNDLED_REGISTRY ) ) {
			return null;
		}
		if ( ! function_exists( 'WP_Filesystem' ) ) {
			require_once ABSPATH . 'wp-admin/includes/file.php';
		}
		WP_Filesystem();
		global $wp_filesystem;
		if ( empty( $wp_filesystem ) ) {
			return null;
		}
		$raw  = $wp_filesystem->get_contents( self::BUNDLED_REGISTRY );
		$data = is_string( $raw ) ? json_decode( $raw, true ) : null;

		if ( ! is_array( $data ) || ! isset( $data['wares'] ) || ! is_array( $data['wares'] ) ) {
			return null;
		}

		return $this->sanitize_wares( $data['wares'] );
	}

	/**
	 * Download a .wp file from a trusted URL and install it.
	 *
	 * Only URLs under github.com/RegionallyFamous/bazaar/releases/ are accepted
	 * unless overridden via the `bazaar_core_apps_allowed_host` filter.
	 *
	 * @param WP_REST_Request $request Incoming request with `url` param.
	 * @return WP_REST_Response|WP_Error
	 */
	public function install_from_url( WP_REST_Request $request ): WP_REST_Response|WP_Error {
		$url          = esc_url_raw( (string) $request->get_param( 'url' ) );
		$allowed_host = (string) apply_filters( 'bazaar_core_apps_allowed_host', 'github.com' );

		if ( wp_parse_url( $url, PHP_URL_HOST ) !== $allowed_host ) {
			return new WP_Error(
				'untrusted_source',
				__( 'The supplied URL is not from an allowed host.', 'bazaar' ),
				array( 'status' => 400 )
			);
		}

		// Enforce the expected path prefix so only genuine release assets are
		// downloadable, even when the host filter is left at its default value.
		$allowed_prefix = (string) apply_filters(
			'bazaar_core_apps_allowed_path_prefix',
			'/RegionallyFamous/bazaar/releases/'
		);
		$url_path       = (string) ( wp_parse_url( $url, PHP_URL_PATH ) ?? '' );
		if ( '' !== $allowed_prefix && ! str_starts_with( $url_path, $allowed_prefix ) ) {
			return new WP_Error(
				'untrusted_path',
				__( 'The supplied URL path is not from an allowed location.', 'bazaar' ),
				array( 'status' => 400 )
			);
		}

		$tmp = $this->download_ware( $url );
		if ( is_wp_error( $tmp ) ) {
			return $tmp;
		}

		$filename = sanitize_file_name( basename( '' !== $url_path ? $url_path : 'ware.wp' ) );
		$manifest = $this->install_ware_file( $tmp, $filename );
		if ( is_wp_error( $manifest ) ) {
			return $manifest;
		}

		return $this->register_ware( $manifest );
	}

	/**
	 * Download a ware archive from a trusted URL to a temporary file.
	 *
	 * Validates HTTP response code, enforces the max-size cap, and writes
	 * the body to a unique temp path for consumption by the WareLoader.
	 *
	 * @param string $url Validated, trusted download URL.
	 * @return string|WP_Error Absolute path to the temporary file, or a WP_Error.
	 */
	private function download_ware( string $url ): string|WP_Error {
		$response = wp_remote_get(
			$url,
			array(
				'timeout'     => 30,
				'redirection' => 0,
				'sslverify'   => true,
			)
		);

		if ( is_wp_error( $response ) ) {
			return new WP_Error(
				'download_failed',
				__( 'Could not download the ware file.', 'bazaar' ),
				array( 'status' => 502 )
			);
		}

		$code = (int) wp_remote_retrieve_response_code( $response );
		if ( 200 !== $code ) {
			return new WP_Error(
				'download_error',
				/* translators: %d: HTTP status code */
				sprintf( __( 'Ware download returned HTTP %d.', 'bazaar' ), $code ),
				array( 'status' => 502 )
			);
		}

		// Reject responses that exceed the maximum ware size before buffering.
		$content_length = (int) wp_remote_retrieve_header( $response, 'content-length' );
		$max_size       = absint( get_option( 'bazaar_max_ware_size', BAZAAR_MAX_UNCOMPRESSED_SIZE ) );
		if ( $content_length > 0 && $content_length > $max_size ) {
			return new WP_Error(
				'download_too_large',
				/* translators: %d: file size in bytes */
				sprintf( __( 'Ware download exceeds the maximum allowed size (%d bytes).', 'bazaar' ), $max_size ),
				array( 'status' => 413 )
			);
		}

		$body = wp_remote_retrieve_body( $response );
		if ( '' === $body ) {
			return new WP_Error(
				'empty_download',
				__( 'Downloaded file is empty.', 'bazaar' ),
				array( 'status' => 502 )
			);
		}

		// Final size check on the actual body in case Content-Length was absent.
		if ( strlen( $body ) > $max_size ) {
			return new WP_Error(
				'download_too_large',
				/* translators: %d: file size in bytes */
				sprintf( __( 'Ware download exceeds the maximum allowed size (%d bytes).', 'bazaar' ), $max_size ),
				array( 'status' => 413 )
			);
		}

		// Write to a unique temp file so WareLoader can read it.
		// wp_tempnam() and WP_Filesystem live in wp-admin/includes/file.php
		// which is not loaded in REST API context — require it before calling.
		if ( ! function_exists( 'WP_Filesystem' ) ) {
			require_once ABSPATH . 'wp-admin/includes/file.php';
		}
		WP_Filesystem();
		global $wp_filesystem;
		if ( empty( $wp_filesystem ) ) {
			return new WP_Error(
				'filesystem_error',
				__( 'Could not initialize filesystem.', 'bazaar' ),
				array( 'status' => 500 )
			);
		}
		$tmp = wp_tempnam( 'bazaar-core-app-.wp' );
		if ( false === $tmp ) {
			return new WP_Error(
				'temp_failed',
				__( 'Could not create a temporary file for the download.', 'bazaar' ),
				array( 'status' => 500 )
			);
		}
		if ( false === $wp_filesystem->put_contents( $tmp, $body, FS_CHMOD_FILE ) ) {
			wp_delete_file( $tmp );
			return new WP_Error(
				'write_failed',
				__( 'Could not write temporary file.', 'bazaar' ),
				array( 'status' => 500 )
			);
		}

		return $tmp;
	}

	/**
	 * Hand a downloaded .wp file to WareLoader for extraction and validation.
	 *
	 * Always cleans up the temporary file, even on failure.
	 *
	 * @param string $tmp      Absolute path to the temporary .wp archive.
	 * @param string $filename Original filename (used as the install slug hint).
	 * @return array<string, mixed>|WP_Error Parsed manifest on success, or a WP_Error.
	 */
	private function install_ware_file( string $tmp, string $filename ): array|WP_Error {
		$manifest = $this->loader->install( $tmp, $filename );
		wp_delete_file( $tmp );

		if ( is_wp_error( $manifest ) ) {
			$manifest->add_data( array( 'status' => 422 ) );
			return $manifest;
		}

		return $manifest;
	}

	/**
	 * Register an installed ware manifest and fire the installed action.
	 *
	 * On registration failure, rolls back the on-disk files to prevent
	 * orphaned ware directories.
	 *
	 * @param array<string, mixed> $manifest Parsed manifest from WareLoader::install().
	 * @return WP_REST_Response|WP_Error 201 response on success, or a WP_Error.
	 */
	private function register_ware( array $manifest ): WP_REST_Response|WP_Error {
		$registered = $this->registry->register( $manifest );
		if ( ! $registered ) {
			$this->loader->delete( $manifest['slug'] );
			return new WP_Error(
				'registry_failed',
				__( 'Ware was installed but could not be added to the registry.', 'bazaar' ),
				array( 'status' => 500 )
			);
		}

		$ware = $this->registry->get( $manifest['slug'] );

		if ( is_array( $ware ) ) {
			JobsController::register_ware_jobs( $ware );
		}

		/**
		 * Fires after a core app is installed via the REST API.
		 *
		 * @param string               $slug     Ware slug.
		 * @param array<string, mixed> $manifest Parsed manifest.
		 * @param string               $source   Install source identifier.
		 */
		do_action( 'bazaar_ware_installed', $manifest['slug'], $manifest, 'core-app' );

		return new WP_REST_Response(
			array(
				'success' => true,
				'message' => sprintf(
					/* translators: %s: ware display name */
					__( '"%s" installed successfully.', 'bazaar' ),
					esc_html( $manifest['name'] ?? '' )
				),
				'ware'    => $ware,
			),
			201
		);
	}

	/**
	 * Sanitize the wares array from the remote catalog.
	 *
	 * @param array<int, mixed> $raw Raw wares array.
	 * @return array<int, array<string, mixed>>
	 */
	private function sanitize_wares( array $raw ): array {
		$out = array();

		foreach ( $raw as $item ) {
			if ( ! is_array( $item ) || empty( $item['slug'] ) ) {
				continue;
			}

			$slug = sanitize_key( (string) $item['slug'] );
			if ( '' === $slug ) {
				continue;
			}

			$tags = array();
			if ( isset( $item['tags'] ) && is_array( $item['tags'] ) ) {
				$tags = array_values(
					array_filter(
						array_map( 'sanitize_key', $item['tags'] ),
						static fn( string $t ) => '' !== $t,
					)
				);
			}

			$out[] = array(
				'slug'         => $slug,
				'name'         => sanitize_text_field( (string) ( $item['name'] ?? '' ) ),
				'description'  => sanitize_textarea_field( (string) ( $item['description'] ?? '' ) ),
				'version'      => sanitize_text_field( (string) ( $item['version'] ?? '' ) ),
				'author'       => sanitize_text_field( (string) ( $item['author'] ?? '' ) ),
				'icon_url'     => esc_url_raw( (string) ( $item['icon_url'] ?? '' ) ),
				'download_url' => esc_url_raw( (string) ( $item['download_url'] ?? '' ) ),
				'tags'         => $tags,
			);
		}

		return $out;
	}
}
